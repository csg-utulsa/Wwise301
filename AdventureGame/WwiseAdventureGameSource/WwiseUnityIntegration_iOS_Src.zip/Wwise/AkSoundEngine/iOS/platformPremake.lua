-- iOS Unity premake module
local platform = {}

function platform.setupTargetAndLibDir(baseTargetDir)
    targetdir(baseTargetDir .. "iOS/%{cfg.buildcfg}")
    libdirs("${WWISESDK}/iOS/$(CONFIGURATION)$(EFFECTIVE_PLATFORM_NAME)/lib/")
end

function platform.platformSpecificConfiguration()
    kind "StaticLib"
    xcodebuildsettings {
        OTHER_LIBTOOLFLAGS = "$(OTHER_LDFLAGS)",
        SEPARATE_STRIP = "NO",
        LINK_WITH_STANDARD_LIBRARIES = "NO"
    }
    links { 
        "Foundation.framework",
        "UIKit.framework",
        "AVFoundation.framework",
        "AudioToolbox.framework",
        "CoreAudio.framework"
    }
end

return platform